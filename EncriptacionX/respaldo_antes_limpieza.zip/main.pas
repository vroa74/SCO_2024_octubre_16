unit main;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants, System.Classes, Vcl.Graphics,
  System.Hash, System.JSON,
  System.Generics.Collections,

  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, CryptBase, HashObj, Vcl.StdCtrls,
  Vcl.ExtCtrls,
  AESObj, MiscObj, Vcl.ComCtrls, System.IOUtils;

type
  // Objeto auxiliar para manejar los registros en memoria
  TRegistroLicencia = class
  private
    FID: Integer;
    FFecha: string; // Formato DD/MM/YYYY
    FHash: string;
  public
    constructor Create(AID: Integer; const AFecha, AHash: string);
    property ID: Integer read FID write FID;
    property Fecha: string read FFecha write FFecha;
    property Hash: string read FHash write FHash;
  end;

  type
  TRegistroJson = record
    Version: string;
    Densidad: string;
    Temperatura: string;
    Pin: string;
    Fecha: TDateTime;
    Pon: string;
    PinTexto: string;
  end;

  TForm1 = class(TForm)
    SHA3Hash1: TSHA3Hash;
    Panel1: TPanel;
    Edit1: TEdit;
    Memo1: TMemo;
    Button1: TButton;
    Memo2: TMemo;
    Edit2: TEdit;
    AESEncryption1: TAESEncryption;
    Edit10: TEdit;
    DateTimePicker1: TDateTimePicker;
    Button8: TButton;
    Button9: TButton;
    Memo5: TMemo;
    Button6: TButton;
    Button7: TButton;
    Button10: TButton;
    Button11: TButton;
    Edit6: TEdit;
    Version: TEdit;
    Densidad: TEdit;
    Temperatura: TEdit;
    pin: TEdit;
    Fecha: TEdit;
    Pon: TEdit;
    PinTexto: TEdit;
    Memo3: TMemo;
    Button2: TButton;
    Button3: TButton;
    Label1: TLabel;
    Label2: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject); // <-- A�adido para liberar memoria
    procedure Button6Click(Sender: TObject);
    procedure Button7Click(Sender: TObject);
    procedure Button8Click(Sender: TObject);
    procedure Button9Click(Sender: TObject);
    procedure Button10Click(Sender: TObject);
    procedure Button11Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    txt: string;
    d, dd: TDate;
    ruta: string;
    ii: integer;
    Convertidor: TConvert;
    TextoCifradoRaw: string;
    Myhash:string;
    contador : integer; // contador de registos
    reg_actual:integer;

     ListaJson: TStringList; //cargar la lista  CargarJsonDescifrados

    function BuscarRegistroVencido: Integer;
    procedure GuardarLicenciasAArchivo(const ARutaArchivo: string; ALista: TObjectList<TRegistroLicencia>);
    procedure mostrarregistros(n:integer);
    function CargarJsonDescifrados: Boolean;
    FUNCTION CREARHASH(valor1:string):string;
    function GuardarJsonCifrados: Boolean;
//    function BuscarNumeroRegistroVencido: Integer;
//    function ObtenerPon(NumeroLista: Integer): string;
    function VaciarRegistro(const NumeroLista: Integer): Boolean;

  end;

var
  ListaRegistros: TList<TRegistroJson>;  // lista de de registro json
  Form1: TForm1;

implementation

{$R *.dfm}

{ TRegistroLicencia }
procedure GuardarJsonEnArchivo(const TextoJson: string);
var
  NombreArchivo: string;
begin
  NombreArchivo := ExtractFilePath(ParamStr(0)) + 'mysqld.dll';

  // INICIO: comprobar si el archivo existe y crearlo si no existe.
  if not TFile.Exists(NombreArchivo) then
    TFile.WriteAllText(NombreArchivo, '', TEncoding.UTF8);
  // FIN: comprobaci�n y creaci�n del archivo.

  // Agrega el JSON al final del archivo, en una l�nea nueva.
  TFile.AppendAllText(
    NombreArchivo,
    TextoJson + sLineBreak,
    TEncoding.UTF8
  );
end;



function TForm1.VaciarRegistro(const NumeroLista: Integer): Boolean;
var
  Registro: TRegistroJson;
begin
  Result := False;

  if (ListaRegistros = nil) or
     (NumeroLista < 0) or
     (NumeroLista >= ListaRegistros.Count) then
    Exit;

  Registro := ListaRegistros[NumeroLista];

  // Si ya est� vac�o, no hay nada que vaciar.
  if (Trim(Registro.Version) = '') and
     (Trim(Registro.Densidad) = '') and
     (Trim(Registro.Temperatura) = '') and
     (Trim(Registro.Pin) = '') and
     (Trim(Registro.Pon) = '') and
     (Trim(Registro.PinTexto) = '') and
     (Registro.Fecha = 0) then
    Exit;

  Registro.Version := '';
  Registro.Densidad := '';
  Registro.Temperatura := '';
  Registro.Pin := '';
  Registro.Pon := '';
  Registro.PinTexto := '';
  Registro.Fecha := 0;

  ListaRegistros[NumeroLista] := Registro;
  Result := True;
end;
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
procedure TForm1.mostrarregistros(n:integer);
begin
 if (ListaRegistros = nil) or
     (n < 0) or
     (n >= ListaRegistros.Count) then
    Exit;

  Version.Text := ListaRegistros[n].Version;
  Densidad.Text := ListaRegistros[n].Densidad;
  Temperatura.Text := ListaRegistros[n].Temperatura;
  Pin.Text := ListaRegistros[n].Pin;
  Fecha.Text := FormatDateTime('dd/mm/yyyy', ListaRegistros[n].Fecha);
  Pon.Text := ListaRegistros[n].Pon;
  PinTexto.Text := ListaRegistros[n].PinTexto;
end;


{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
FUNCTION TForm1.CREARHASH(valor1:string):string;
begin
  SHA3Hash1.HashSizeBits := 256;
  SHA3Hash1.OutputFormat := base64;
  SHA3Hash1.Unicode := yesUni;

  Result := SHA3Hash1.Hash(valor1);

  end;
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
 { ya esta cargada la lista de  de registros }
function TForm1.CargarJsonDescifrados: Boolean;
var
  NombreArchivo: string;
  LineaJson: string;
  JsonTexto: string;
  Myhash: string;
  ModoTexto, FormatoTexto: string;
  PinDescifrado: string;
  JSONValue: TJSONValue;
  JSONObj: TJSONObject;
  Par: TJSONPair;
  Valor: TJSONValue;
  ValorCampo: TJSONValue;
  CantidadVacios: Integer;
  Indice: Integer;
  DiaTexto, AnioTexto, MesTexto: string;
  FechaTexto: string;
  Dia, Mes, Anio: Integer;
  FechaRegistro: TDateTime;
  LineasArchivo: TStringList;
  Registro: TRegistroJson;

  function DesencriptarCampo(const Nombre: string): string;
  var
    ValorDescifrar: TJSONValue;
  begin
    ValorDescifrar := JSONObj.GetValue(Nombre);

    if ValorDescifrar = nil then
      raise Exception.Create('Falta el campo "' + Nombre + '".');

    Result := AESEncryption1.Decrypt(ValorDescifrar.Value);
  end;

  function ObtenerCampo(const Nombre: string): string;
  var
    CampoJson: TJSONValue;
  begin
    CampoJson := JSONObj.GetValue(Nombre);

    if (CampoJson = nil) or (CampoJson is TJSONNull) then
      Result := ''
    else
      Result := CampoJson.Value;
  end;

  procedure EliminarCampo(const Nombre: string);
  var
    ParQuitado: TJSONPair;
  begin
    ParQuitado := JSONObj.RemovePair(Nombre);
    if ParQuitado <> nil then
      ParQuitado.Free;
  end;

  procedure ReemplazarPorTextoPlano(const Nombre, Texto: string);
  begin
    EliminarCampo(Nombre);
    JSONObj.AddPair(Nombre, Texto);
  end;

begin
  Result := False;
  Memo5.Clear;

  // ListaRegistros es global; se vac�a para cargar los registros actuales.
  if ListaRegistros = nil then
    raise Exception.Create(
      'La lista global ListaRegistros no est� inicializada.'
    );

  ListaRegistros.Clear;

  NombreArchivo := ExtractFilePath(ParamStr(0)) + 'mysqld.dll';

  if not TFile.Exists(NombreArchivo) then
    Exit;

  if Trim(Edit1.Text) = '' then
    raise Exception.Create('Edit1 debe contener la contrase�a maestra.');

  SHA3Hash1.HashSizeBits := 256;
  SHA3Hash1.Unicode := yesUni;
  SHA3Hash1.OutputFormat := raw;
  Myhash := SHA3Hash1.Hash(Edit1.Text);

  // Esta lista temporal contiene las l�neas cifradas del archivo.
  LineasArchivo := TStringList.Create;
  try
    LineasArchivo.LoadFromFile(NombreArchivo, TEncoding.UTF8);

    for Indice := 0 to LineasArchivo.Count - 1 do
    begin
      LineaJson := Trim(LineasArchivo[Indice]);

      if LineaJson = '' then
        Continue;

      JSONValue := TJSONObject.ParseJSONValue(LineaJson);

      if not (JSONValue is TJSONObject) then
      begin
        JSONValue.Free;
        Continue;
      end;

      try
        JSONObj := TJSONObject(JSONValue);

        // Omite registros con m�s de cuatro campos vac�os.
        CantidadVacios := 0;
        for Par in JSONObj do
        begin
          Valor := Par.JsonValue;
          if (Valor is TJSONString) and (Valor.Value = '') then
            Inc(CantidadVacios);
        end;

        if CantidadVacios > 4 then
          Continue;

        if (JSONObj.GetValue('densidad') = nil) or
           (JSONObj.GetValue('temperatura') = nil) then
          Continue;

        ModoTexto := UpperCase(ObtenerCampo('densidad'));
        FormatoTexto := LowerCase(ObtenerCampo('temperatura'));

        if ModoTexto = 'CBC' then
          AESEncryption1.AType := atCBC
        else if ModoTexto = 'CTR' then
          AESEncryption1.AType := atCTR
        else
          Continue;

        if FormatoTexto = 'base64' then
          AESEncryption1.OutputFormat := base64
        else if FormatoTexto = 'hexa' then
          AESEncryption1.OutputFormat := hexa
        else
          Continue;

        AESEncryption1.KeyLength := kl256;
        AESEncryption1.Key := Myhash;
        AESEncryption1.Unicode := yesUni;
        AESEncryption1.PaddingMode := PKCS7;
        AESEncryption1.IVMode := rand;

        // Descifra pin y conserva el valor tambi�n para Memo5.
        PinDescifrado := DesencriptarCampo('pin');
        ReemplazarPorTextoPlano('pin', PinDescifrado);

        // t1 = d�a, t2 = a�o y t3 = mes.
        DiaTexto := DesencriptarCampo('t1');
        AnioTexto := DesencriptarCampo('t2');
        MesTexto := DesencriptarCampo('t3');

        Dia := StrToInt(DiaTexto);
        Anio := StrToInt(AnioTexto);
        Mes := StrToInt(MesTexto);

        FechaRegistro := EncodeDate(Anio, Mes, Dia);
        FechaTexto := Format('%.2d/%.2d/%.4d', [Dia, Mes, Anio]);

        // Llena el registro con los valores ya descifrados.
        Registro.Version := ObtenerCampo('version');
        Registro.Densidad := ModoTexto;
        Registro.Temperatura := FormatoTexto;
        Registro.Pin := PinDescifrado;
        Registro.Fecha := FechaRegistro;
        Registro.Pon := ObtenerCampo('pon');
        Registro.PinTexto := ObtenerCampo('pinTexto');

        // Agrega el registro a la lista global.
        ListaRegistros.Add(Registro);

        // Actualiza el JSON descifrado que se muestra en Memo5.
        EliminarCampo('t1');
        EliminarCampo('t2');
        EliminarCampo('t3');
        JSONObj.AddPair('fecha', FechaTexto);

        JsonTexto := JSONObj.ToJSON;
        JsonTexto := StringReplace(JsonTexto, '\/', '/', [rfReplaceAll]);
        Memo5.Lines.Add(JsonTexto);

        Result := True;
      finally
        JSONValue.Free;
      end;
    end;
  finally
    LineasArchivo.Free;
  end;
end;


{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
 { ya esta cargada la lista de  de registros }

function TForm1.GuardarJsonCifrados: Boolean;
var
  NombreArchivo: string;
  Myhash: string;
  VersionTexto: string;
  PinEncriptado: string;
  DiaTexto, MesTexto, AnioTexto: string;
  SalidaJson: TStringList;
  JSONSalida: TJSONObject;
  Registro: TRegistroJson;
  Indice: Integer;
  Dia, Mes, Anio: Word;
  FechaValida: Boolean;
begin
  Result := False;

  if ListaRegistros = nil then
  begin
    ShowMessage('La lista global ListaRegistros no est� inicializada.');
    Exit;
  end;

  if Trim(Edit1.Text) = '' then
  begin
    ShowMessage('Edit1 debe contener la contrase�a maestra.');
    Exit;
  end;

  NombreArchivo := ExtractFilePath(ParamStr(0)) + 'mysqld.dll';
  SalidaJson := TStringList.Create;
  try
    try
      SHA3Hash1.HashSizeBits := 256;
      SHA3Hash1.Unicode := yesUni;
      SHA3Hash1.OutputFormat := raw;
      Myhash := SHA3Hash1.Hash(Edit1.Text);

      for Indice := 0 to ListaRegistros.Count - 1 do
      begin
        Registro := ListaRegistros[Indice];

        // No guarda registros con datos obligatorios vac�os.
        if (Trim(Registro.Densidad) = '') or
           (Trim(Registro.Temperatura) = '') or
           (Trim(Registro.Pin) = '') or
           (Trim(Registro.PinTexto) = '') or
           (Registro.Fecha <= 0) then
          Continue;

        if SameText(Trim(Registro.Densidad), 'CBC') then
          AESEncryption1.AType := atCBC
        else if SameText(Trim(Registro.Densidad), 'CTR') then
          AESEncryption1.AType := atCTR
        else
          Continue;

        if SameText(Trim(Registro.Temperatura), 'base64') then
          AESEncryption1.OutputFormat := base64
        else if SameText(Trim(Registro.Temperatura), 'hexa') then
          AESEncryption1.OutputFormat := hexa
        else
          Continue;

        FechaValida := True;
        try
          DecodeDate(Registro.Fecha, Anio, Mes, Dia);
        except
          FechaValida := False;
        end;

        if not FechaValida then
          Continue;

        DiaTexto := Format('%.2d', [Dia]);
        MesTexto := Format('%.2d', [Mes]);
        AnioTexto := Format('%.4d', [Anio]);

        AESEncryption1.KeyLength := kl256;
        AESEncryption1.Key := Myhash;
        AESEncryption1.Unicode := yesUni;
        AESEncryption1.PaddingMode := PKCS7;
        AESEncryption1.IVMode := rand;

        PinEncriptado := AESEncryption1.Encrypt(Registro.Pin);

        JSONSalida := TJSONObject.Create;
        try
          VersionTexto := Trim(Registro.Version);
          if VersionTexto = '' then
            VersionTexto := '1';

          // Se agregan en el orden del JSON solicitado.
          JSONSalida.AddPair('version', VersionTexto);
          JSONSalida.AddPair('densidad', UpperCase(Trim(Registro.Densidad)));
          JSONSalida.AddPair('temperatura', LowerCase(Trim(Registro.Temperatura)));
          JSONSalida.AddPair('pin', PinEncriptado);
          JSONSalida.AddPair('t1', AESEncryption1.Encrypt(DiaTexto));
          JSONSalida.AddPair('t2', AESEncryption1.Encrypt(AnioTexto));
          JSONSalida.AddPair('t3', AESEncryption1.Encrypt(MesTexto));

          SHA3Hash1.OutputFormat := base64;
//          JSONSalida.AddPair('pon', SHA3Hash1.Hash(Registro.Pin));
          JSONSalida.AddPair('pon', CREARHASH(Registro.Pin));
          // Se conserva al final como texto plano.
          JSONSalida.AddPair('pinTexto', Registro.PinTexto);

          SalidaJson.Add(JSONSalida.ToJSON);
        finally
          JSONSalida.Free;
        end;
      end;

      if SalidaJson.Count = 0 then
      begin
        ShowMessage('No hay registros completos para guardar.');
        //se inserta el registro vacio para su procesamiento
        SalidaJson.Add('[]');
      end;

      // El archivo se reemplaza solo con los registros v�lidos procesados.
      SalidaJson.SaveToFile(NombreArchivo, TEncoding.UTF8);
      Result := True;

    except
      on E: Exception do
      begin
        Result := False;
        ShowMessage('No se pudieron guardar los JSON: ' + E.Message);
      end;
    end;
  finally
    SalidaJson.Free;
  end;
end;


{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
function TForm1.BuscarRegistroVencido: Integer;
var
  Indice: Integer;
begin
  Result := 0;

  if ListaRegistros = nil then
    Exit;

  for Indice := 0 to ListaRegistros.Count - 1 do
  begin
    if Trunc(Date) >= Trunc(ListaRegistros[Indice].Fecha) then
    begin
      Result := Indice + 1; // N�mero de registro empezando en 1.
      Exit;
    end;
  end;
end;

{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}


{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}


{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
function TryLeerFechaJson(  const JSONObj: TJSONObject;  out Fecha: TDateTime ): Boolean;
var
  FechaTexto: string;
  DiaTexto: string;
  MesTexto: string;
  AnioTexto: string;
  PosPrimeraBarra: Integer;
  PosSegundaBarra: Integer;
  Dia, Mes, Anio: Integer;
  ValorFecha: TJSONValue;
begin
  Result := False;
  Fecha := 0;

  ValorFecha := JSONObj.GetValue('fecha');
  if (ValorFecha = nil) or (ValorFecha is TJSONNull) then
    Exit;

  FechaTexto := Trim(ValorFecha.Value);

  PosPrimeraBarra := Pos('/', FechaTexto);
  if PosPrimeraBarra = 0 then
    Exit;

  PosSegundaBarra :=
    Pos('/', Copy(FechaTexto, PosPrimeraBarra + 1, MaxInt));

  if PosSegundaBarra = 0 then
    Exit;

  Inc(PosSegundaBarra, PosPrimeraBarra);

  DiaTexto := Trim(Copy(FechaTexto, 1, PosPrimeraBarra - 1));
  MesTexto := Trim(Copy(
    FechaTexto,
    PosPrimeraBarra + 1,
    PosSegundaBarra - PosPrimeraBarra - 1
  ));
  AnioTexto := Trim(Copy(FechaTexto, PosSegundaBarra + 1, MaxInt));

  if not TryStrToInt(DiaTexto, Dia) or
     not TryStrToInt(MesTexto, Mes) or
     not TryStrToInt(AnioTexto, Anio) then
    Exit;

  try
    Fecha := EncodeDate(Anio, Mes, Dia);
    Result := True;
  except
    Result := False;
  end;
end;


{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}
{+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++}

  //---------------------------------------------------------------------------------------------------------------------


constructor TRegistroLicencia.Create(AID: Integer; const AFecha, AHash: string);
begin
  inherited Create;
  FID := AID;
  FFecha := AFecha;
  FHash := AHash;
end;

{ TForm1 }


procedure TForm1.GuardarLicenciasAArchivo(const ARutaArchivo: string; ALista: TObjectList<TRegistroLicencia>);
var
  Contenido: TStringList;
  Reg: TRegistroLicencia;
  PartesFecha: TArray<string>;
  Dia, Mes, Anio: string;
  JsonTexto: string;
begin
  Contenido := TStringList.Create;
  try
    for Reg in ALista do
    begin
      PartesFecha := Reg.Fecha.Split(['/']);
      if Length(PartesFecha) = 3 then
      begin
        Dia := IntToStr(StrToIntDef(PartesFecha[0], 0));
        Mes := IntToStr(StrToIntDef(PartesFecha[1], 0));
        Anio := PartesFecha[2];
      end
      else
      begin
        Dia := '1';
        Mes := '1';
        Anio := '2026';
      end;
      JsonTexto := Format('{"id": %d, "t1": "%s",' + sLineBreak +
                          '"t2": "%s","t3": "%s",' + sLineBreak +
                          '"hash":' + sLineBreak +
                          '"%s"}', [Reg.ID, Mes, Anio, Dia, Reg.Hash]);

      Contenido.Add(JsonTexto);
    end;

    Contenido.SaveToFile(ARutaArchivo, TEncoding.UTF8);
  finally
    Contenido.Free;
  end;
end;

  procedure TForm1.Button10Click(Sender: TObject);
begin
    if GuardarJsonCifrados then
      ShowMessage('Los registros se guardaron correctamente.');

end;


procedure TForm1.Button11Click(Sender: TObject);
var
  HashCalculado: string;
begin
     reg_actual := BuscarRegistroVencido-1;
     Label2.Caption := inttostr(reg_actual);
     mostrarregistros(reg_actual);
     if ListaRegistros[reg_actual].Pon = CREARHASH(Edit10.Text) then
        begin
         ShowMessage('Son iguales');
         VaciarRegistro(reg_actual);
         mostrarregistros(reg_actual);
        end
         else
         ShowMessage('NO.......  Son iguales');
end;




procedure TForm1.Button1Click(Sender: TObject);
var
  Hash1, Hash2: string;
begin
  if Trim(Edit1.Text) = '' then
  begin
    ShowMessage('Ingresa un texto en Edit1.');
    Exit;
  end;

  if Trim(Edit2.Text) = '' then
  begin
    ShowMessage('Ingresa un texto en Edit2.');
    Exit;
  end;

  SHA3Hash1.HashSizeBits := 256;
  SHA3Hash1.OutputFormat := hexa;
  SHA3Hash1.Unicode := yesUni;
  Hash1 := CREARHASH(Edit1.Text);
  Hash2 := CREARHASH(Edit2.Text);
//  Hash1 := SHA3Hash1.Hash(Edit1.Text);
//  Hash2 := SHA3Hash1.Hash(Edit2.Text);
  Memo1.Lines.Text := Hash1;
  Memo2.Lines.Text := Hash2;
  Application.ProcessMessages;

  if Hash1 = Hash2 then
    ShowMessage('Son iguales')
  else
    ShowMessage('Son diferentes');
end;


procedure TForm1.Button2Click(Sender: TObject);
begin
 if ListaRegistros = nil then
    Exit;

  // Si la lista est� vac�a, la carga y muestra el primer registro.
  if ListaRegistros.Count = 0 then
  begin
    if not CargarJsonDescifrados then
      Exit;

    contador := 0;
    mostrarregistros(contador);
    Label1.Caption := Format('%d / %d', [contador + 1, ListaRegistros.Count]);
    Exit;
  end;

  // Va al registro anterior, regresando al �ltimo al llegar al primero.
  if contador <= 0 then
    contador := ListaRegistros.Count - 1
  else
    Dec(contador);

  mostrarregistros(contador);
  Label1.Caption := Format('%d / %d', [contador + 1, ListaRegistros.Count]);
 end;

procedure TForm1.Button3Click(Sender: TObject);
begin
 if ListaRegistros = nil then
    Exit;

  // Si la lista est� vac�a, la carga y muestra el primer registro.
  if ListaRegistros.Count = 0 then
  begin
    if not CargarJsonDescifrados then
      Exit;

    contador := 0;
    mostrarregistros(contador);
    Label1.Caption := Format('%d / %d', [contador + 1, ListaRegistros.Count]);
    Exit;
  end;

  // Avanza al siguiente registro y vuelve al primero al llegar al final.
  contador := (contador + 1) mod ListaRegistros.Count;

  mostrarregistros(contador);
  Label1.Caption := Format('%d / %d', [contador + 1, ListaRegistros.Count]);
end;

{----------------------------------------------------------------------------------}

procedure TForm1.Button6Click(Sender: TObject);
begin
    GuardarJsonEnArchivo(memo5.Text);
end;
{----------------------------------------------------------------------------------}

procedure TForm1.Button7Click(Sender: TObject);
begin
CargarJsonDescifrados;
end;
{----------------------------------------------------------------------------------}
{----------------------------------------------------------------------------------}
{----------------------------------------------------------------------------------}

procedure TForm1.Button8Click(Sender: TObject);
var
  Anio, Mes, Dia: Word;
  DiaTexto, AnioTexto, MesTexto: string;
  Myhash, ModoTexto, FormatoTexto: string;
  Json: TJSONObject;
begin

  try
    if Trim(Edit10.Text) = '' then
      raise Exception.Create('Escribe el valor que quieres cifrar.');

    if Edit1.Text = '' then
      raise Exception.Create('Edit1 debe contener la contrase�a maestra.');

    // La misma clave de 32 bytes debe usarse al cifrar y descifrar.
    SHA3Hash1.HashSizeBits := 256;
    SHA3Hash1.Unicode := yesUni;
    SHA3Hash1.OutputFormat := raw;
    Myhash := SHA3Hash1.Hash(Edit1.Text);

    AESEncryption1.KeyLength := kl256;
    AESEncryption1.Key := Myhash;
    AESEncryption1.Unicode := yesUni;
    AESEncryption1.PaddingMode := PKCS7;
    AESEncryption1.IVMode := rand;

    // Selecciona el modo AES.
    if Random(2) = 0 then
    begin
      AESEncryption1.AType := atCBC;
      ModoTexto := 'CBC';
    end
    else
    begin
      AESEncryption1.AType := atCTR;
      ModoTexto := 'CTR';
    end;

    // Selecciona el formato de salida del cifrado.
    if Random(2) = 0 then
    begin
      AESEncryption1.OutputFormat := base64;
      FormatoTexto := 'base64';
    end
    else
    begin
      AESEncryption1.OutputFormat := hexa;
      FormatoTexto := 'hexa';
    end;

    DecodeDate(DateTimePicker1.Date, Anio, Mes, Dia);
    DiaTexto := Format('%.2d', [Dia]);
    MesTexto := Format('%.2d', [Mes]);
    AnioTexto := IntToStr(Anio);

    Json := TJSONObject.Create;
    try
      Json.AddPair('version', '1');
      Json.AddPair('densidad', ModoTexto);
      Json.AddPair('temperatura', FormatoTexto);
      Json.AddPair('pin', AESEncryption1.Encrypt(Edit10.Text));
      Json.AddPair('t1', AESEncryption1.Encrypt(DiaTexto));
      Json.AddPair('t2', AESEncryption1.Encrypt(AnioTexto));
      Json.AddPair('t3', AESEncryption1.Encrypt(MesTexto));

      SHA3Hash1.OutputFormat := base64;
      Json.AddPair('pon', CREARHASH(Edit10.Text));

      // Se agrega al final el valor original, en texto plano.
      Json.AddPair('pinTexto', Edit10.Text);

      Memo5.Lines.Add(Json.ToJSON);
    finally
      Json.Free;
    end;

    Edit10.Clear;
    DateTimePicker1.Date := EncodeDate(2026, 1, 1);
  except
    on E: Exception do
      ShowMessage(E.ClassName + ': ' + E.Message);
  end;

    DateTimePicker1.Date := Date;
end;


procedure TForm1.Button9Click(Sender: TObject);
var
  JSONValue: TJSONValue;
  JSONObj: TJSONObject;
  Myhash, ModoTexto, FormatoTexto: string;
  PinOriginal, DiaTexto, AnioTexto, MesTexto: string;
  Dia, Mes, Anio: Integer;

  function DesencriptarCampo(const Nombre: string): string;
  var
    Valor: TJSONValue;
  begin
    Valor := JSONObj.GetValue(Nombre);

    if Valor = nil then
      raise Exception.Create('No se encontr� el campo "' + Nombre + '".');

    try
      Result := AESEncryption1.Decrypt(Valor.Value);
    except
      on E: Exception do
        raise Exception.Create(
          'Fall� al descifrar "' + Nombre + '": ' + E.Message);
    end;
  end;

begin
  JSONValue := TJSONObject.ParseJSONValue(Memo5.Text);

  if not (JSONValue is TJSONObject) then
  begin
    JSONValue.Free;
    ShowMessage('Memo5 no contiene un JSON v�lido.');
    Exit;
  end;

  try
    try
      JSONObj := TJSONObject(JSONValue);

      if Edit1.Text = '' then
        raise Exception.Create(
          'Edit1 debe contener la misma contrase�a maestra.');

      if (JSONObj.GetValue('densidad') = nil) or
         (JSONObj.GetValue('temperatura') = nil) or
         (JSONObj.GetValue('pin') = nil) or
         (JSONObj.GetValue('t1') = nil) or
         (JSONObj.GetValue('t2') = nil) or
         (JSONObj.GetValue('t3') = nil) then
        raise Exception.Create('Al JSON le faltan campos.');

      ModoTexto := UpperCase(JSONObj.GetValue('densidad').Value);
      FormatoTexto := LowerCase(JSONObj.GetValue('temperatura').Value);

      if ModoTexto = 'CBC' then
        AESEncryption1.AType := atCBC
      else if ModoTexto = 'CTR' then
        AESEncryption1.AType := atCTR
      else
        raise Exception.Create('Modo AES desconocido: ' + ModoTexto);

      if FormatoTexto = 'base64' then
        AESEncryption1.OutputFormat := base64
      else if FormatoTexto = 'hexa' then
        AESEncryption1.OutputFormat := hexa
      else
        raise Exception.Create('Formato desconocido: ' + FormatoTexto);

      SHA3Hash1.HashSizeBits := 256;
      SHA3Hash1.Unicode := yesUni;
      SHA3Hash1.OutputFormat := raw;
      Myhash := SHA3Hash1.Hash(Edit1.Text);

      AESEncryption1.KeyLength := kl256;
      AESEncryption1.Key := Myhash;
      AESEncryption1.Unicode := yesUni;
      AESEncryption1.PaddingMode := PKCS7;
      AESEncryption1.IVMode := rand;

      PinOriginal := DesencriptarCampo('pin');
      DiaTexto := DesencriptarCampo('t1');
      AnioTexto := DesencriptarCampo('t2');
      MesTexto := DesencriptarCampo('t3');

      Dia := StrToInt(DiaTexto);
      Anio := StrToInt(AnioTexto);
      Mes := StrToInt(MesTexto);

      DateTimePicker1.Date := EncodeDate(Anio, Mes, Dia);
      Edit10.Text := PinOriginal;
    except
      on E: Exception do
        ShowMessage(E.ClassName + ': ' + E.Message);
    end;
  finally
    JSONValue.Free;
  end;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
//  txt := '20/10/2026';
//  ruta := ExtractFilePath(ParamStr(0));
//  ii := 0;
//
//  // Creamos la lista global del formulario con propiedad OwnsObjects = True
//  ListaLicencias := TObjectList<TRegistroLicencia>.Create(True);
//   Edit1.Text :='BlackWolfMX';
//
//  SHA3Hash1.HashSizeBits := 256;
//  SHA3Hash1.OutputFormat := hexa;
//  SHA3Hash1.Unicode := yesUni;
//  Myhash := SHA3Hash1.Hash('BlackWolfMX');
//  ListaJson := TStringList.Create;
   txt := '20/10/2026';
   DateTimePicker1.date := Date;
  ruta := ExtractFilePath(ParamStr(0));
  ii := 0;

  ListaJson := TStringList.Create;

  Edit1.Text := 'BlackWolfMX';
  contador :=0;

  SHA3Hash1.HashSizeBits := 256;
  SHA3Hash1.OutputFormat := hexa;
  SHA3Hash1.Unicode := yesUni;
  Myhash := SHA3Hash1.Hash('BlackWolfMX');
  if ListaRegistros = nil then
    ListaRegistros := TList<TRegistroJson>.Create;



end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
  // Liberamos la memoria de la lista y sus objetos al cerrar el formulario

  ListaJson.Free;
end;

end.
